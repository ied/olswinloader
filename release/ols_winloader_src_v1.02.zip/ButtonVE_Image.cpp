//
// BUTTONVE_IMAGE.CPP
// Code contained in this file is hereby released to the public domain. 
// Ian Davis, 4/24/2007
// http://www.codeproject.com/KB/vista/vistathemebuttons.aspx
//

//
// Owner Drawn WinXP/Vista themes aware image button implementation...
//
#include "stdafx.h"
#include "ButtonVE_Image.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CButtonVE_Image, CButtonVE)

BEGIN_MESSAGE_MAP(CButtonVE_Image, CButtonVE)
END_MESSAGE_MAP()

