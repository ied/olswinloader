//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ols_winloader.rc
//
#define IDADVANCE                       3
#define IDDEFAULT                       3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_OLS_WINLOADER_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDR_HEXFILE                     129
#define IDR_BINFILE                     130
#define IDR_BITFILE                     131
#define IDR_MCSFILE                     132
#define IDB_REFRESH                     133
#define IDD_ADVANCED_DIALOG             134
#define IDB_START                       135
#define IDB_ADVANCED                    136
#define IDB_CANCEL                      155
#define IDC_STATIC_ICON                 1000
#define IDC_IMAGEFILE                   1001
#define IDC_BROWSE                      1002
#define IDC_ANALYZERPORT_LIST           1003
#define IDC_PROGRESS                    1004
#define IDC_STATIC_HELP                 1005
#define IDC_STATUS                      1006
#define IDC_STATUS2                     1007
#define IDC_REFRESH                     1008
#define IDC_BACKUP                      1011
#define IDC_NOERASE                     1012
#define IDC_OLSSTATUS                   1013
#define IDC_RUNMODE                     1014
#define IDC_SELFTEST                    1015
#define IDC_IGNOREJEDIC                 1016
#define IDC_PORTSPEED                   1017
#define IDC_LINKS                       1020
#define IDC_TABCTRL                     1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
